tinyMCE.addI18n('cy.advhr_dlg',{
width:"Lled",
size:"Uchder",
noshade:"Dim cysgod"
});