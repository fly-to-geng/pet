tinyMCE.addI18n('no.advhr_dlg',{
width:"Bredde",
size:"St\u00F8rrelse",
noshade:"Ingen skygge"
});