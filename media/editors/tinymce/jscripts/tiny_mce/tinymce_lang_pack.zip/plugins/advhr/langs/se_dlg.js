tinyMCE.addI18n('se.advhr_dlg',{
width:"Bredd",
size:"H\u00F6jd",
noshade:"Ingen skugga"
});