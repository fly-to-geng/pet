tinyMCE.addI18n('ja.advhr_dlg',{
width:"\u5E45",
size:"\u9AD8\u3055",
noshade:"\u5F71\u306A\u3057"
});