tinyMCE.addI18n('gl.advhr_dlg',{
width:"Ancho",
size:"Alto",
noshade:"Sen sombra"
});