tinyMCE.addI18n('it.paste_dlg',{
text_title:"Premere CTRL+V sulla tastiera per incollare il testo nella finestra.",
text_linebreaks:"Mantieni interruzioni di riga",
word_title:"Premere CTRL+V sulla tastiera per incollare il testo nella finestra."
});