tinyMCE.addI18n('de.paste_dlg',{
text_title:"Dr\u00FCcken Sie auf Ihrer Tastatur Strg+V, um den Text einzuf\u00FCgen.",
text_linebreaks:"Zeilenumbr\u00FCche beibehalten",
word_title:"Dr\u00FCcken Sie auf Ihrer Tastatur Strg+V, um den Text einzuf\u00FCgen."
});